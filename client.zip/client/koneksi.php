<?php
        $host       = "localhost";
        $username   = "root";
        $password   = "";
        $database   = "cinashop";
        $koneksi    = mysqli_connect($host, $username, $password, $database);

    